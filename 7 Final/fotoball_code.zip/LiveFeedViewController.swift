//
//  LiveFeedViewController.swift
//  Fotoball
//
//  Created by teamFotoball on 4/12/15.
//

import UIKit
import WebKit

class LiveFeedViewController: UIViewController {
    
    var recording = false
    var camera: Int = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(red: 220/255, green: 220/255, blue: 220/255, alpha: 1.0)
        btnRecord.layer.borderColor = UIColor.grayColor().CGColor
        btnRecord.layer.cornerRadius = 5.0
        btnRecord.layer.borderWidth = 0.5
        btnRecord.layer.backgroundColor = UIColor.whiteColor().CGColor
        camera = 1
        
        // connect with video stream
        let url = NSURL(string: "http://192.168.1.2")
        
        let request = NSURLRequest(URL: url!)
        
        webView.loadRequest(request)
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setCam(camNum: Int) {
        // had to change this from setCamera due to naming conventions
        camera = camNum
    }
    
    func getVideo() -> NSObject {
        // return stored video
        return 0
    }
    
    @IBOutlet weak var btnRecord: UIButton!
    
    @IBOutlet weak var webView: UIWebView!
    
    @IBAction func recordClick(sender: AnyObject) {
        // start or stop recording
        if (recording == false)
        {
            recording = !recording
            btnRecord.setTitle("  Stop Recording", forState: UIControlState.Normal)
        } else {
            recording = !recording
            btnRecord.setTitle("  Start Recording", forState: UIControlState.Normal)
        }
    }
}