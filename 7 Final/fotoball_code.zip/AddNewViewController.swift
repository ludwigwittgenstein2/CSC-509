//
//  AddNewViewController.swift
//  Fotoball
//
//  Created by teamFotoball on 4/12/15.
//

import UIKit

class AddNewViewController: UIViewController {

    // array of existing fotoballs
    var fotoball_list: Array <String> = [];
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(red: 220/255, green: 220/255, blue: 220/255, alpha: 1.0)
        btnConnect.layer.borderColor = UIColor.grayColor().CGColor
        btnConnect.layer.cornerRadius = 5.0
        btnConnect.layer.borderWidth = 0.5
        btnConnect.layer.backgroundColor = UIColor.whiteColor().CGColor
        btnCancel.layer.borderColor = UIColor.grayColor().CGColor
        btnCancel.layer.cornerRadius = 5.0
        btnCancel.layer.borderWidth = 0.5
        btnCancel.layer.backgroundColor = UIColor.whiteColor().CGColor
        
        fotoball_list = ["test_1", "test_2", "Default fotoball test", "alpha 0.85b"]
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    private func syncBall(name: String, ip_add: String, port: Int) {
        //sync based on passed info
    }

    @IBOutlet weak var btnConnect: UIButton!
    @IBOutlet weak var btnCancel: UIButton!
}

