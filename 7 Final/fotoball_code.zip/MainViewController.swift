//
//  MainViewController.swift
//  Fotoball
//
//  Created by teamFotoball on 4/12/15.
//

import UIKit

class MainViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    let fotoballs = ["test_ball_1", "test_ball_2", "proto3", "alpha 0.85b"]
    let textCellIdentifier = "TextCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblBalls.delegate = self
        tblBalls?.dataSource = self
        self.view.backgroundColor = UIColor(red: 220/255, green: 220/255, blue: 220/255, alpha: 1.0)
        btnAddNew.layer.borderColor = UIColor.grayColor().CGColor
        btnAddNew.layer.cornerRadius = 5.0
        btnAddNew.layer.borderWidth = 0.5
        btnAddNew.layer.backgroundColor = UIColor.whiteColor().CGColor
        btnRefresh.layer.borderColor = UIColor.grayColor().CGColor
        btnRefresh.layer.cornerRadius = 5.0
        btnRefresh.layer.borderWidth = 0.5
        btnRefresh.layer.backgroundColor = UIColor.whiteColor().CGColor
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func activateBall(fotoball: NSObject) {
        //recive and activate new Fotoball
    }
    
    func addBall() {
        // handled via tab bar to load AddNewViewController
    }
    
    func getBalls() -> NSArray {
        // return array of balls
        return fotoballs
    }
    
    func numberOfSectionsInTableView(tblBalls: UITableView) -> Int {
        return 1
    }
    
    func tableView(tblBalls: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fotoballs.count
    }
    
    func tableView(tblBalls: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        // load databse info into tableView
        let cell = tblBalls.dequeueReusableCellWithIdentifier(textCellIdentifier, forIndexPath: indexPath) as! UITableViewCell
        let row = indexPath.row
        cell.textLabel?.text = fotoballs[row]
        
        return cell
    }
    
    func tableView(tblBalls: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tblBalls.deselectRowAtIndexPath(indexPath, animated: true)
        let row = indexPath.row
        println(fotoballs[row])
    }
    
    @IBOutlet weak var btnAddNew: UIButton!
    @IBOutlet weak var btnRefresh: UIButton!
    
    @IBOutlet weak var tblBalls: UITableView!
    
    @IBAction func addNew(sender: AnyObject) {
    }
    
    @IBAction func refresh(sender: AnyObject) {
    }
    
}

